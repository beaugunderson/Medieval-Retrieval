
This is a low-polygon model of a Well. 
Available in three different formats.
Blender .blend , FBX and OBJ.

Software used: Blender 2.79a & Adobe Photoshop.

Texture Maps: Diffuse,Normal and Specular maps 2048x2048 pixels
UV Mapped - Yes 

Faces Count  : 1074
Vertex Count  :
 1059

Renderer   : Blender Cycles

Please contact me if you have any problem with the model.
.................................................................

Animated Heaven - Designs of Eternity